SEIMBANG V7 — iPad-friendly working prototype

Quick test (desktop):
1. Open Seimbang_V7_iPad_Friendly.html in Chrome or Edge.
2. Fill in the profile form and click Save profile & open dashboard.
3. Everything runs from this one file.

Best way to SHARE with iPhone/iPad users:
Publish index.html to a static website host and send the resulting HTTPS link.
For GitHub Pages: create a public repository, upload index.html to the repository root,
then enable Pages via Settings > Pages > Deploy from a branch > main > /(root).
Wait until GitHub Pages gives you a URL, and open that URL in Safari.

IMPORTANT:
Opening an HTML attachment inside Apple Files, WhatsApp, Mail or another preview
may block JavaScript and browser storage. No HTML-only code change can guarantee
that those previews behave like a normal browser.

The prototype stores profiles and wellness entries only in that visitor's own
browser (if browser storage is permitted). It does not synchronise across devices.
Calorie estimates are for general adult guidance only, not medical advice.
